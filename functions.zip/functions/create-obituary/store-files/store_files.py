import boto3
import json
import requests
client = boto3.client('ssm')
s3_client = boto3.client('s3')


def handler(event, context):

    bucket = 's3-thelastshow'

    audio = 'voice.mp3'

    picture = 'picture.jpg'

    audio_resp = s3_client.get_object(Bucket=bucket, Key=audio)
    picture_resp = s3_client.get_object(Bucket=bucket, Key=picture)

    aud = audio_resp['Body'].read()
    pic = picture_resp['Body'].read()

    response_2 = client.get_parameter(
        Name='cloud_api', WithDecryption=True,
    )

    cloud_name = "dvuhdytlr"

    api_key = response_2['Parameter']['Value']

    aud_resp = requests.post(f"https://api.cloudinary.com/v1_1/{cloud_name}/upload", files={"file": aud}, data={
                             "upload_preset": "audio_and_pictures", "resource_type": "auto"}, auth=("366726625531221", api_key))

    pic_resp = requests.post(f"https://api.cloudinary.com/v1_1/{cloud_name}/upload", files={"file": pic}, data={
                             "upload_preset": "audio_and_pictures", "resource_type": "auto"}, auth=("366726625531221", api_key))

    pic_url = json.loads(pic_resp.text)["url"]
    aud_url = json.loads(aud_resp.text)["url"]

    output = {
        "audio_url": aud_url, "picture_url": pic_url
    }

    return output
